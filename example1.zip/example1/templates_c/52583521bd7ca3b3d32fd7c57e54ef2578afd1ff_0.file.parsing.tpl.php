<?php
/* Smarty version 3.1.39, created on 2021-12-27 07:37:56
  from 'C:\xampp\htdocs\smarty-master\example1\templates\parsing.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61c95f44aff158_58040655',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '52583521bd7ca3b3d32fd7c57e54ef2578afd1ff' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty-master\\example1\\templates\\parsing.tpl',
      1 => 1640587029,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61c95f44aff158_58040655 (Smarty_Internal_Template $_smarty_tpl) {
?>Welcome <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
 to Smarty
<?php echo '<script'; ?>
 language="javascript">
  var foo = <?php echo $_smarty_tpl->tpl_vars['foo']->value;?>
;
  function dosomething() {
    alert("foo is " + foo);
  }
  dosomething();
<?php echo '</script'; ?>
><?php }
}
