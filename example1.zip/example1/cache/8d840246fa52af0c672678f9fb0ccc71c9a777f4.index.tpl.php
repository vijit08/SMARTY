<?php
/* Smarty version 3.1.39, created on 2021-12-27 06:50:00
  from 'C:\xampp\htdocs\smarty-master\example1\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61c954083a46b9_50803972',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '4dd32472eef8798ef4f8437d9698eb0a0ea616ed' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty-master\\example1\\templates\\index.tpl',
      1 => 1640584163,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_61c954083a46b9_50803972 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?php
';?>
$t = date("H");

if ($t < "20") {
  echo "Have a good day!";
} else {
  echo "Have a good night!";
}
<?php echo '?>';
}
}
