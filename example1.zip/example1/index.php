<?php
/**
 * Example Application
 *
 *
 */
require '../libs/Smarty.class.php';
$smarty = new Smarty;

$smarty->template_dir = 'C:/xampp/htdocs/smarty-master/example1/templates';
$smarty->config_dir = 'C:/xampp/htdocs/smarty-master/example1/config';
$smarty->cache_dir = 'C:/xampp/smarty-master/example1/cache';
$smarty->compile_dir = 'C:/xampp/smarty-master/example1/templates_c';
$smarty->assign('name','uzzal !!');
$smarty->assign('x',10);
$smarty->assign('y',20);


$smarty->assign('firstname', 'Doug');
$smarty->assign('lastname', 'Evans');
$smarty->assign('meetingPlace', 'New York');
$smarty->assign('app', array("a"));


$smarty->assign('Contacts',
    array('fax' => '555-222-9876',
          'email' => 'zaphod@slartibartfast.example.com',
          'phone' => array('home' => '555-444-3333',
                           'cell' => '555-111-1234')
                           )
         );
$smarty->assign('Contact', array(
            '555-222-9876',
            'zaphod@slartibartfast.example.com',
             array('555-444-3333',
                   '555-111-1234')
             ));
$data = $smarty->createData();
$data->assign('foo','data');
$data->assign('bar','bar-data');
$smarty->assign("title","Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nisi nulla eos consectetur praesentium assumenda doloremque repellendus corrupti inventore alias dicta error ratione harum rerum suscipit, sint vitae numquam id delectus!");
$smarty->assign('articleTitle', 'next x-men film, x3, delayed.');
$smarty->assign('concat', "Psychics predict world didn't end");
$smarty->assign('c', 'Cold Wave Linked to Temperatures.');
$smarty->assign('paragraph',
                 "War Dims Hope for Peace. Child's Death Ruins Couple's Holiday.\n\n
                 Man is Fatally Slain. Death Causes Loneliness, Feeling of Isolation."
                );

$smarty->assign('combine', 'Smokers are Productive, but Death Cuts Efficiency.');

$smarty->display('variables.tpl');
?>


